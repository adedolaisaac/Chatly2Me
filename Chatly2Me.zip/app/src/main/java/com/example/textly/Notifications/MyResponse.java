package com.example.textly.Notifications;

public class MyResponse {

    public int success;
}
